package com.example.nueorotoneapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Register extends AppCompatActivity {


    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://nueorotineappdatabase-default-rtdb.firebaseio.com/");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final EditText full_name = findViewById(R.id.full_name);
        final EditText username = findViewById(R.id.username);
        final EditText email = findViewById(R.id.email1);
        final EditText password = findViewById(R.id.password);
        final EditText con_Password = findViewById(R.id.con_Password);

        final Button registerBTN = findViewById(R.id.registerButton);
        final TextView loginNowBTN = findViewById(R.id.loginNowButton);

        registerBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //extract the data from the EditTexts
                final String fullnameTxt = full_name.getText().toString();
                final String usernameTxt = username.getText().toString();
                final String emailTxt = email.getText().toString();
                final String passwordTxt = password.getText().toString();
                final String con_PasswordTxt = con_Password.getText().toString();

                if (fullnameTxt.isEmpty() || usernameTxt.isEmpty() || emailTxt.isEmpty() || passwordTxt.isEmpty() || con_PasswordTxt.isEmpty() ){
                    Toast.makeText(Register.this, "Please enter in all fields",Toast.LENGTH_SHORT).show();


                }
                else if (!passwordTxt.equals(con_PasswordTxt)){
                    Toast.makeText(Register.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                } else {
                    databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.hasChild(usernameTxt)){
                                Toast.makeText(Register.this,"Username already used",Toast.LENGTH_SHORT).show();

                            }else{
                                databaseReference.child("users").child(usernameTxt).child("fullname").setValue(fullnameTxt);
                                databaseReference.child("users").child(usernameTxt).child("email").setValue(emailTxt);
                                databaseReference.child("users").child(usernameTxt).child("password").setValue(passwordTxt);

                                Toast.makeText(Register.this,"Registration Successful.",Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });


                }


            }
        });
        loginNowBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

}