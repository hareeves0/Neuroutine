package com.example.harrisonsettings

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView



class MainActivity : AppCompatActivity() {
    private val pf = Prefs(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val midnight_theme_shape = ContextCompat.getDrawable(this, R.drawable.midnight_shape)
        val forest_theme_shape = ContextCompat.getDrawable(this, R.drawable.forest_shape)
        val mars_theme_shape = ContextCompat.getDrawable(this, R.drawable.mars_shape)
        val creamcicle_theme_shape = ContextCompat.getDrawable(this, R.drawable.creamcicle)



        var current_theme = pf.loadData()
        if (current_theme.equals(1)){
           val account_layout_theme = findViewById<LinearLayout>(R.id.account_setting_id)
            val Appearance_layout_theme = findViewById<LinearLayout>(R.id.appearance_setting_id)
            val Tutorial_layout_theme = findViewById<LinearLayout>(R.id.tutorial_setting_id)
            val Support_layout_theme = findViewById<LinearLayout>(R.id.support_setting_id)
            val Logout_layout_theme = findViewById<LinearLayout>(R.id.account_logout_id)

            val account_text_color = findViewById<TextView>(R.id.account_info_text)
            val appearance_text_color = findViewById<TextView>(R.id.appearance_info_text)
            val tutorial_text_color = findViewById<TextView>(R.id.tutorial_info_text)
            val support_text_color = findViewById<TextView>(R.id.support_info_text)
            val logout_text_color = findViewById<TextView>(R.id.account_logout_text)

            account_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            appearance_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            tutorial_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            support_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            logout_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            account_layout_theme.background = midnight_theme_shape
            Appearance_layout_theme.background = midnight_theme_shape
            Tutorial_layout_theme.background = midnight_theme_shape
            Support_layout_theme.background = midnight_theme_shape
            Logout_layout_theme.background = midnight_theme_shape

        }

        if (current_theme.equals(2)) {
            val account_layout_theme = findViewById<LinearLayout>(R.id.account_setting_id)
            val Appearance_layout_theme = findViewById<LinearLayout>(R.id.appearance_setting_id)
            val Tutorial_layout_theme = findViewById<LinearLayout>(R.id.tutorial_setting_id)
            val Support_layout_theme = findViewById<LinearLayout>(R.id.support_setting_id)
            val Logout_layout_theme = findViewById<LinearLayout>(R.id.account_logout_id)

            val account_text_color = findViewById<TextView>(R.id.account_info_text)
            val appearance_text_color = findViewById<TextView>(R.id.appearance_info_text)
            val tutorial_text_color = findViewById<TextView>(R.id.tutorial_info_text)
            val support_text_color = findViewById<TextView>(R.id.support_info_text)
            val logout_text_color = findViewById<TextView>(R.id.account_logout_text)

            account_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            appearance_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            tutorial_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            support_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            logout_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            account_layout_theme.background = forest_theme_shape
            Appearance_layout_theme.background = forest_theme_shape
            Tutorial_layout_theme.background = forest_theme_shape
            Support_layout_theme.background = forest_theme_shape
            Logout_layout_theme.background = forest_theme_shape
        }

        if (current_theme.equals(3)) {
            val account_layout_theme = findViewById<LinearLayout>(R.id.account_setting_id)
            val Appearance_layout_theme = findViewById<LinearLayout>(R.id.appearance_setting_id)
            val Tutorial_layout_theme = findViewById<LinearLayout>(R.id.tutorial_setting_id)
            val Support_layout_theme = findViewById<LinearLayout>(R.id.support_setting_id)
            val Logout_layout_theme = findViewById<LinearLayout>(R.id.account_logout_id)

            val account_text_color = findViewById<TextView>(R.id.account_info_text)
            val appearance_text_color = findViewById<TextView>(R.id.appearance_info_text)
            val tutorial_text_color = findViewById<TextView>(R.id.tutorial_info_text)
            val support_text_color = findViewById<TextView>(R.id.support_info_text)
            val logout_text_color = findViewById<TextView>(R.id.account_logout_text)

            account_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            appearance_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            tutorial_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            support_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            logout_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            account_layout_theme.background = mars_theme_shape
            Appearance_layout_theme.background = mars_theme_shape
            Tutorial_layout_theme.background = mars_theme_shape
            Support_layout_theme.background = mars_theme_shape
            Logout_layout_theme.background = mars_theme_shape
        }

        if (current_theme.equals(4)) {
            val account_layout_theme = findViewById<LinearLayout>(R.id.account_setting_id)
            val Appearance_layout_theme = findViewById<LinearLayout>(R.id.appearance_setting_id)
            val Tutorial_layout_theme = findViewById<LinearLayout>(R.id.tutorial_setting_id)
            val Support_layout_theme = findViewById<LinearLayout>(R.id.support_setting_id)
            val Logout_layout_theme = findViewById<LinearLayout>(R.id.account_logout_id)

            val account_text_color = findViewById<TextView>(R.id.account_info_text)
            val appearance_text_color = findViewById<TextView>(R.id.appearance_info_text)
            val tutorial_text_color = findViewById<TextView>(R.id.tutorial_info_text)
            val support_text_color = findViewById<TextView>(R.id.support_info_text)
            val logout_text_color = findViewById<TextView>(R.id.account_logout_text)

            account_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            appearance_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            tutorial_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            support_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            logout_text_color.setTextColor(Color.parseColor("#FFFFFF"))
            account_layout_theme.background = creamcicle_theme_shape
            Appearance_layout_theme.background = creamcicle_theme_shape
            Tutorial_layout_theme.background = creamcicle_theme_shape
            Support_layout_theme.background = creamcicle_theme_shape
            Logout_layout_theme.background = creamcicle_theme_shape
        }

        val account_button = findViewById<Button>(R.id.account_click)
        val appearance_button = findViewById<Button>(R.id.appearance_click)
        val support_button = findViewById<Button>(R.id.support_click)
        val tutorial_button = findViewById<Button>(R.id.tutorial_click)
        val logout_button = findViewById<Button>(R.id.logout_click)
        val home_button = findViewById<Button>(R.id.logout_click)

        account_button.setOnClickListener {
            val intent = Intent(this, Account::class.java)
            startActivity(intent)
        }
        appearance_button.setOnClickListener {
            val intent = Intent(this, Appearance::class.java)
            startActivity(intent)
        }
        support_button.setOnClickListener {
            val intent = Intent(this, Support::class.java)
            startActivity(intent)
        }
        tutorial_button.setOnClickListener {
            val intent = Intent(this, Tutorial::class.java)
            startActivity(intent)
        }
        logout_button.setOnClickListener {
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }
        home_button.setOnClickListener {
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }
    }
}

