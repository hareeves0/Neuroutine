package com.example.harrisonsettings

import android.content.Context
import android.content.SharedPreferences

class Prefs(context1: Context){
    private var context: Context? = context1

    fun saveData(chosenTheme:Int) {
        var s: SharedPreferences? = context!!.getSharedPreferences("shared", Context.MODE_PRIVATE)
        var editor = s?.edit()
        editor?.putInt("chosen", chosenTheme)
        editor?.apply()
    }
    fun loadData(): Int{
        var s: SharedPreferences = context!!.getSharedPreferences("shared", Context.MODE_PRIVATE)
        val back = s.getInt("chosen", 0)
        return back
    }

}