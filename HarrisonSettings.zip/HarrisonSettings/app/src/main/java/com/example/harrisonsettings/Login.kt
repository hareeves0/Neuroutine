package com.example.harrisonsettings

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class Login : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        var databaseReference = FirebaseDatabase.getInstance()
            .getReferenceFromUrl("https://neuroutinetest-default-rtdb.firebaseio.com/users")
        setContentView(R.layout.login)
        val phone = findViewById<EditText>(R.id.phone)
        val password = findViewById<EditText>(R.id.password)
        val loginBtn = findViewById<Button>(R.id.loginBtn2)
        val registerNowBtn = findViewById<TextView>(R.id.registerNowBtn)
        loginBtn.setOnClickListener {
            val phoneTxt = phone.text.toString()
            val passwordTxt = phone.text.toString()
            if (phoneTxt.isEmpty() || passwordTxt.isEmpty()) {
                Toast.makeText(
                    this@Login,
                    "Please Enter your email or password",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)

                databaseReference.child("users")
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            if (snapshot.hasChild(phoneTxt)) {
                                val getPassword = snapshot.child(phoneTxt).child("password")
                                    .getValue(
                                        String::class.java
                                    )
                                if (getPassword == passwordTxt) {
                                    Toast.makeText(
                                        this@Login,
                                        "Login Successful",
                                        Toast.LENGTH_SHORT
                                    ).show()

                                    //startActivity(new Intent(Login.this,MainActivity.class));

                                    //finish();
                                } else {
                                    Toast.makeText(
                                        this@Login,
                                        "Welcome!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } else {
                                Toast.makeText(
                                    this@Login,
                                    "Welcome!",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }

                        override fun onCancelled(error: DatabaseError) {}
                    })
            }
        }
        registerNowBtn.setOnClickListener {
            startActivity(
                Intent(
                    this@Login,
                    Register::class.java
                )
            )
        }
    }
}