package com.example.harrisonsettings

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import zendesk.chat.ChatEngine
import zendesk.chat.VisitorInfo
import zendesk.classic.messaging.MessagingActivity
import zendesk.core.Zendesk
import zendesk.support.Support
import zendesk.chat.Chat
import zendesk.answerbot.AnswerBot

class Support : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.support)
        val back_button = findViewById<Button>(R.id.back_button_support)
        Zendesk.INSTANCE.init(this, "https://skygowifi.zendesk.com",
            "ef014ed10de7f7c8b63ea3280f38a73eba3fb8dbbf0d0815",
            "mobile_sdk_client_9fa9904e7433e1ceba85");
        Support.INSTANCE.init(Zendesk.INSTANCE);
        AnswerBot.INSTANCE.init(Zendesk.INSTANCE, Support.INSTANCE);
        Chat.INSTANCE.init(this, "Sh5aDyvE235O7gel1qNc7G9bAG9jk4E4ySsjQ0RN");

        val supportChat = findViewById<Button>(R.id.chat_button)
        supportChat.setOnClickListener { view ->
            MessagingActivity.builder()
                .withEngines(ChatEngine.engine())
                .show(view.getContext());
        }
        val visitorInfo = VisitorInfo.builder().build()

        back_button.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}