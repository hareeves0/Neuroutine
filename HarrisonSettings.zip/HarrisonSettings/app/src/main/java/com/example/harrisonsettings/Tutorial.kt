package com.example.harrisonsettings

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.PagerAdapter

class Tutorial  : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tutorial)
        val back_button = findViewById<Button>(R.id.back_button_tutorial)
        var currentSlideIndex = 0
        var currentSlide: ImageView = findViewById(R.id.e_image)
        currentSlide.setImageResource(R.drawable.tutorial1)
        back_button.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val slideButton = findViewById<View>(R.id.slide_button)
        slideButton.setOnClickListener {
            if (currentSlideIndex == 0) {
                currentSlide.setImageResource(R.drawable.tutorial2)
                currentSlideIndex++
            }
            else if (currentSlideIndex == 1) {
                currentSlide.setImageResource(R.drawable.tutorial3)
                currentSlideIndex++
            }
            else if (currentSlideIndex == 2) {
                currentSlide.setImageResource(R.drawable.tutorial4)
                currentSlideIndex++
                slideButton.alpha = 0f
            }

        }
    }
}