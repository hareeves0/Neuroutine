package com.example.harrisonsettings


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class Appearance : AppCompatActivity() {
    private val pf = Prefs(this)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.appearance)
        val back_button = findViewById<Button>(R.id.back_button_appearance)
        val midnight_button = findViewById<Button>(R.id.midnight_button)
        val original_button = findViewById<Button>(R.id.original_button)
        val forest_button = findViewById<Button>(R.id.forest_button)
        val mars_button = findViewById<Button>(R.id.mars_button)
        val cream_button = findViewById<Button>(R.id.cream_button)
        var choice_theme = 0
        back_button.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        midnight_button.setOnClickListener {
            choice_theme = 1
            pf.saveData(choice_theme)
        }
        original_button.setOnClickListener {
            choice_theme = 0
            pf.saveData(choice_theme)
        }
        forest_button.setOnClickListener {
            choice_theme = 2
            pf.saveData(choice_theme)

        }
        mars_button.setOnClickListener {
            choice_theme = 3
            pf.saveData(choice_theme)

        }
        cream_button.setOnClickListener {
            choice_theme = 4
            pf.saveData(choice_theme)
        }

    }

}

