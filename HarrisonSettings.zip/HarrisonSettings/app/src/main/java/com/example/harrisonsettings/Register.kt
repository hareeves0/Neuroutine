package com.example.harrisonsettings;

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener


class Register : AppCompatActivity() {
    var databaseReference: DatabaseReference = FirebaseDatabase.getInstance()
        .getReferenceFromUrl("https://neuroutinetest-default-rtdb.firebaseio.com/")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContentView(R.layout.register)
        val fullname = findViewById<EditText>(R.id.fullname)
        val email = findViewById<EditText>(R.id.email)
        val phone = findViewById<EditText>(R.id.phone)
        val password = findViewById<EditText>(R.id.password)
        val conPassword = findViewById<EditText>(R.id.conPassword)
        val registerBtn = findViewById<Button>(R.id.registerBtn)
        val loginNowBtn = findViewById<TextView>(R.id.loginNowBtn)
        registerBtn.setOnClickListener {
            val fullnameTxt = fullname.text.toString()
            val emailTxt = email.text.toString()
            val phoneTxt = phone.text.toString()
            val passwordTxt = password.text.toString()
            val conPasswordTxt = conPassword.text.toString()
            if (fullnameTxt.isEmpty() || emailTxt.isEmpty() || phoneTxt.isEmpty() || passwordTxt.isEmpty()) {
                Toast.makeText(this@Register, "Please fill in all fields!", Toast.LENGTH_SHORT)
                    .show()
            } else if (passwordTxt != conPasswordTxt) {
                Toast.makeText(this@Register, "Passwords do not match", Toast.LENGTH_SHORT).show()
            } else {
                databaseReference.child("users")
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            if (snapshot.hasChild(phoneTxt)) {
                                Toast.makeText(
                                    this@Register,
                                    "username is already in use",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                databaseReference.child("users").child(phoneTxt).child("fullname")
                                    .setValue(fullnameTxt)
                                databaseReference.child("users").child(phoneTxt).child("email")
                                    .setValue(emailTxt)
                                databaseReference.child("users").child(phoneTxt).child("password")
                                    .setValue(passwordTxt)
                                Toast.makeText(
                                    this@Register,
                                    "User Registered Successfully",
                                    Toast.LENGTH_SHORT
                                ).show()
                                finish()
                            }
                        }

                        override fun onCancelled(error: DatabaseError) {}
                    })
            }

        }
        loginNowBtn.setOnClickListener { finish() }
    }
}