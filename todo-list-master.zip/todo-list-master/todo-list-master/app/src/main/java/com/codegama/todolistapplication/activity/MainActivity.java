package com.codegama.todolistapplication.activity;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.codegama.todolistapplication.R;
import com.codegama.todolistapplication.adapter.TaskAdapter;
import com.codegama.todolistapplication.bottomSheetFragment.CreateTaskBottomSheetFragment;
import com.codegama.todolistapplication.bottomSheetFragment.ShowCalendarViewBottomSheet;
import com.codegama.todolistapplication.broadcastReceiver.AlarmBroadcastReceiver;
import com.codegama.todolistapplication.database.DatabaseClient;
import com.codegama.todolistapplication.model.Task;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends BaseActivity implements CreateTaskBottomSheetFragment.setRefreshListener {

    @BindView(R.id.taskRecycler)
    RecyclerView taskRecycler;
    @BindView(R.id.addTask)
    TextView addTask;
    TaskAdapter taskAdapter;
    ItemClickListener itemClickListener;
    List<Task> tasks = new ArrayList<>();
    @BindView(R.id.noDataImage)
    ImageView noDataImage;
    @BindView(R.id.calendar)
    ImageView calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        setUpAdapter();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        ComponentName receiver = new ComponentName(this, AlarmBroadcastReceiver.class);
        PackageManager pm = getPackageManager();
        pm.setComponentEnabledSetting(receiver, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
        Glide.with(getApplicationContext()).load(R.drawable.first_note).into(noDataImage);

        addTask.setOnClickListener(view -> {
            CreateTaskBottomSheetFragment createTaskBottomSheetFragment = new CreateTaskBottomSheetFragment();
            createTaskBottomSheetFragment.setTaskId(0, false, this, MainActivity.this);
            createTaskBottomSheetFragment.show(getSupportFragmentManager(), createTaskBottomSheetFragment.getTag());
        });

        getSavedTasks();

        calendar.setOnClickListener(view -> {
            ShowCalendarViewBottomSheet showCalendarViewBottomSheet = new ShowCalendarViewBottomSheet();
            showCalendarViewBottomSheet.show(getSupportFragmentManager(), showCalendarViewBottomSheet.getTag());
        });
    }

    @Override
    public void onPerformDirectAction(@NonNull String actionId, @NonNull Bundle arguments, @NonNull CancellationSignal cancellationSignal, @NonNull Consumer<Bundle> resultListener) {
        super.onPerformDirectAction(actionId, arguments, cancellationSignal, resultListener);
    }

    public void setUpAdapter() {
        Collections.reverse(tasks);
        itemClickListener=new ItemClickListener() {
            @Override
            public void onClick(int position) {
                final Task temp=tasks.get(position);

                Intent intent =new Intent(MainActivity.this,descriptionpage.class);
                intent.putExtra("tvTime",temp.getFirstAlarmTime());
                intent.putExtra("tvTaskname",temp.getTaskTitle());
                intent.putExtra("tvDesc",temp.getTaskDescrption());
                intent.putExtra("tvDate",temp.getDate());
               startActivity(intent);

            }
        };
        taskAdapter = new TaskAdapter(this, tasks, (CreateTaskBottomSheetFragment.setRefreshListener) this, itemClickListener);

        taskRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        taskRecycler.setAdapter(taskAdapter);
    }

    private void getSavedTasks() {

        class GetSavedTasks extends AsyncTask<Void, Void, List<Task>> {
            @Override
            protected List<Task> doInBackground(Void... voids) {
                tasks = DatabaseClient
                        .getInstance(getApplicationContext())
                        .getAppDatabase()
                        .dataBaseAction()
                        .getAllTasksList();
                return tasks;
            }

            @Override
            protected void onPostExecute(List<Task> tasks) {
                super.onPostExecute(tasks);
                noDataImage.setVisibility(tasks.isEmpty() ? View.VISIBLE : View.GONE);
                setUpAdapter();
            }
        }

        GetSavedTasks savedTasks = new GetSavedTasks();
        savedTasks.execute();
    }

    @Override
    public void refresh() {
        getSavedTasks();
    }
}

//package com.codegama.todolistapplication.activity;
//
//        import android.content.ComponentName;
//        import android.content.pm.PackageManager;
//        import android.os.AsyncTask;
//        import android.os.Bundle;
//        import android.view.View;
//        import android.view.WindowManager;
//        import android.widget.ImageView;
//        import android.widget.LinearLayout;
//        import android.widget.TextView;
//
//        import androidx.recyclerview.widget.LinearLayoutManager;
//        import androidx.recyclerview.widget.RecyclerView;
//
//        import com.bumptech.glide.Glide;
//        import com.codegama.todolistapplication.R;
//        import com.codegama.todolistapplication.adapter.TaskAdapter;
//        import com.codegama.todolistapplication.bottomSheetFragment.CreateTaskBottomSheetFragment;
//        import com.codegama.todolistapplication.bottomSheetFragment.ShowCalendarViewBottomSheet;
//        import com.codegama.todolistapplication.broadcastReceiver.AlarmBroadcastReceiver;
//        import com.codegama.todolistapplication.database.DatabaseClient;
//        import com.codegama.todolistapplication.model.Task;
//
//        import java.util.ArrayList;
//        import java.util.List;
//
//        import butterknife.BindView;
//        import butterknife.ButterKnife;
//
//public class MainActivity extends BaseActivity implements CreateTaskBottomSheetFragment.setRefreshListener {
//
//    // Bind the RecyclerView in the layout to this variable.
//    @BindView(R.id.taskRecycler)
//    RecyclerView taskRecycler;
//
//    // Bind the "add task" button in the layout to this variable.
//    @BindView(R.id.addTask)
//    TextView addTask;
//
//    // Declare a TaskAdapter to handle displaying tasks in the RecyclerView.
//    TaskAdapter taskAdapter;
//
//    // A list to hold Task objects retrieved from the database.
//    List<Task> tasks = new ArrayList<>();
//
//    // Bind the "no data" image view in the layout to this variable.
//    @BindView(R.id.noDataImage)
//    ImageView noDataImage;
//
//    // Bind the calendar icon in the layout to this variable.
//    @BindView(R.id.calendar)
//    ImageView calendar;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//
//        // Inflate the layout for this activity.
//        setContentView(R.layout.activity_main);
//
//        // Bind views with ButterKnife.
//        ButterKnife.bind(this);
//
//        // Set up the TaskAdapter and RecyclerView.
//        setUpAdapter();
//
//        // Keep the screen on while this activity is visible.
//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
//
//        // Enable the AlarmBroadcastReceiver.
//        ComponentName receiver = new ComponentName(this, AlarmBroadcastReceiver.class);
//        PackageManager pm = getPackageManager();
//        pm.setComponentEnabledSetting(receiver, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
//
//        // Load the "no data" image.
//        Glide.with(getApplicationContext()).load(R.drawable.first_note).into(noDataImage);
//
//        // Show the CreateTaskBottomSheetFragment when the "add task" button is clicked.
//        addTask.setOnClickListener(view -> {
//            CreateTaskBottomSheetFragment createTaskBottomSheetFragment = new CreateTaskBottomSheetFragment();
//            createTaskBottomSheetFragment.setTaskId(0, false, this, MainActivity.this);
//            createTaskBottomSheetFragment.show(getSupportFragmentManager(), createTaskBottomSheetFragment.getTag());
//        });
//
//        // Get the saved tasks from the database and display them in the RecyclerView.
//        getSavedTasks();
//
//        // Show the ShowCalendarViewBottomSheet when the calendar icon is clicked.
//        calendar.setOnClickListener(view -> {
//            ShowCalendarViewBottomSheet showCalendarViewBottomSheet = new ShowCalendarViewBottomSheet();
//            showCalendarViewBottomSheet.show(getSupportFragmentManager(), showCalendarViewBottomSheet.getTag());
//        });
//    }
//
//    /**
//     * Set up the TaskAdapter and RecyclerView.
//     */
//    public void setUpAdapter() {
//        taskAdapter = new TaskAdapter(this, tasks, this);
//        taskRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
//        taskRecycler.setAdapter(taskAdapter);
//    }
//
///**
// * Retrieve saved tasks
// // This method retrieves all saved tasks from the database using an AsyncTask
// private void getSavedTasks() {
// // Define an AsyncTask to perform database operations in the background thread
// class GetSavedTasks extends AsyncTask<Void, Void, List<Task>> {
//
// // This method retrieves all saved tasks from the database in the background thread
// @Override
// protected List<Task> doInBackground(Void... voids) {
// tasks = DatabaseClient
// .getInstance(getApplicationContext())
// .getAppDatabase()
// .dataBaseAction()
// .getAllTasksList();
// return tasks;
// }
//
// // This method is called after the database operation is complete in the background thread
// // It updates the UI with the retrieved task list
// @Override
// protected void onPostExecute(List<Task> tasks) {
// super.onPostExecute(tasks);
// noDataImage.setVisibility(tasks.isEmpty() ? View.VISIBLE : View.GONE);
// setUpAdapter();
// }
// }
//
// // Create an instance of the AsyncTask and execute it to retrieve tasks from the database
// GetSavedTasks savedTasks = new GetSavedTasks();
// savedTasks.execute();
// }
//
// // This method is called when the create task bottom sheet is dismissed and the task list needs to be refreshed
// @Override
// public void refresh() {
// getSavedTasks();
// }