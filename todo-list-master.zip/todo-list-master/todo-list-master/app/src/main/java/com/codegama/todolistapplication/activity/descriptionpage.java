package com.codegama.todolistapplication.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.codegama.todolistapplication.R;

public class descriptionpage extends AppCompatActivity {
TextView tvTaskname,tvDecripiton,tvTiming,tvDate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_descriptionpage);
        tvTaskname=(TextView)findViewById(R.id.tvDname);
        tvDecripiton=(TextView)findViewById(R.id.tvDname);
        tvTiming=(TextView)findViewById(R.id.tvTimedesc);
        tvDate=(TextView)findViewById(R.id.tvDateDescription);
        Bundle extras = getIntent().getExtras();
        tvTaskname.setText(extras.getString("tvTaskname").toString());
        tvDecripiton.setText(extras.getString("tvDesc").toString());
//       tvTiming.setText(extras.getString("tvTime").toString());
        tvDate.setText(extras.getString("tvDate").toString());
    }
}