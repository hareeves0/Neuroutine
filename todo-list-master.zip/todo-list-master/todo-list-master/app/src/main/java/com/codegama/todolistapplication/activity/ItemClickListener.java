package com.codegama.todolistapplication.activity;

 public interface ItemClickListener {
    void onClick(int position);
}